#!/usr/bin/env python3

from aws_cdk import core

from test_vpc_id.test_vpc_id_stack import TestVpcIdStack


app = core.App()
TestVpcIdStack(app, "test-vpc-id")

app.synth()
