from aws_cdk import  (
core,
aws_ec2 as ec2,
aws_autoscaling as autoscaling,
aws_elasticloadbalancing as elb
)


class TestVpcIdStack(core.Stack):

    def __init__(self, scope: core.Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # The code that defines your stack goes here

        vpc = ec2.Vpc(
        self, "test_vpc_id",
        cidr="10.0.0.0/16",
        max_azs=2,
        nat_gateways=1,
        subnet_configuration=[
            ec2.SubnetConfiguration(name="public1", cidr_mask=24, subnet_type=ec2.SubnetType.PUBLIC),
            ec2.SubnetConfiguration(name="public2", cidr_mask=24, subnet_type=ec2.SubnetType.PUBLIC),
            ec2.SubnetConfiguration(name="private1", cidr_mask=24, subnet_type=ec2.SubnetType.PRIVATE),
            ec2.SubnetConfiguration(name="private2", cidr_mask=24, subnet_type=ec2.SubnetType.PRIVATE)
        ]
    )  

        asg = autoscaling.AutoScalingGroup(
            self, "ASG",
            vpc=vpc,
            instance_type=ec2.InstanceType.of(
                ec2.InstanceClass.BURSTABLE2, ec2.InstanceSize.MICRO
            ),
            machine_image=ec2.AmazonLinuxImage(),
    )

        lb = elb.LoadBalancer(
            self, "LB",
            vpc=vpc,
            internet_facing=True,
            health_check={"port": 80}
    )
        lb.add_target(asg)

        listener = lb.add_listener(external_port=80)
        listener.connections.allow_default_port_from_any_ipv4("Open to the world")
